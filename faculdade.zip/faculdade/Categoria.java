public enum Categoria {
    FESTA,
    ESPORTIVO,
    SHOW,
    CULTURAL,
    OUTROS
}
